import React from "react";

export default function CustomErrorPage() {
  return <div>Error 404 page not found</div>;
}
