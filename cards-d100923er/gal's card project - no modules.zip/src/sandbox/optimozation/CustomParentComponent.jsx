import React from "react";

export default function CustomParentComponent() {
  return <div>CustomParentComponent</div>;
}
