import React from "react";

export default function MyCardsPage() {
  return <div>MyCardsPage</div>;
}
